﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace BizzyBeeGames
{
	public class UIAnimationBehaviour : UIMonoBehaviour
	{
		#region Inspector Variables

		#endregion

		#region Member Variables

		#endregion

		#region Properties

		#endregion

		#region Unity Methods

		#endregion

		#region Public Methods

		public void Shake()
		{

		}

		#endregion

		#region Protected Methods

		#endregion

		#region Private Methods

		#endregion
	}
}
