﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace BizzyBeeGames
{
	public class ToggleSliderHandle : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
	{
		#region Inspector Variables

		#endregion

		#region Member Variables

		#endregion

		#region Properties

		#endregion

		#region Unity Methods

		#endregion

		#region Public Methods

		public void OnBeginDrag(PointerEventData eventData)
		{
		}

		public void OnDrag(PointerEventData eventData)
		{
		}

		public void OnEndDrag(PointerEventData eventData)
		{
		}

		#endregion

		#region Protected Methods

		#endregion

		#region Private Methods

		#endregion
	}
}
